//
//  NotificationHistory.m
//  PushApp
//
//  Created by tothesky on 25/03/2017.
//  Copyright © 2017 tothesky. All rights reserved.
//

#import "DBNotificationHistory.h"
#import "AppConstant.h"
@implementation DBNotificationHistory
//-------------------------------------------------------------------------------------------------------------------------------------------------
+ (NSString *)primaryKey
//-------------------------------------------------------------------------------------------------------------------------------------------------
{
    return NOTIFICATIONHISTORY_OBJECTID;
}

//-------------------------------------------------------------------------------------------------------------------------------------------------
+ (long long)lastUpdatedAt
//-------------------------------------------------------------------------------------------------------------------------------------------------
{
    DBNotificationHistory *dbnotificationhistory = [[[DBNotificationHistory allObjects] sortedResultsUsingKeyPath:@"updatedAt" ascending:YES] lastObject];
    return dbnotificationhistory.updatedAt;
}

@end
