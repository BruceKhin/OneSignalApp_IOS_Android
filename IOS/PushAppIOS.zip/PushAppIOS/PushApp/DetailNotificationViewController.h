//
//  DetailNotificationViewController.h
//  PushApp
//
//  Created by tothesky on 25/03/2017.
//  Copyright © 2017 tothesky. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailNotificationViewController : UIViewController
@property (strong, readwrite, nonatomic) NSString *str_title;
@property (strong, readwrite, nonatomic) NSString *str_content;
@property (strong, readwrite, nonatomic) NSString *str_objID;


@property (weak, nonatomic) IBOutlet UILabel *lbl_content;
@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
@property (weak, nonatomic) IBOutlet UITextView *txt_content;

@end
