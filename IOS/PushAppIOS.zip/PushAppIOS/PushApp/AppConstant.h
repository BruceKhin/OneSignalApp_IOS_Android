//
//  AppConstant.h
//  PushApp
//
//  Created by tothesky on 25/03/2017.
//  Copyright © 2017 tothesky. All rights reserved.
//

#ifndef AppConstant_h
#define AppConstant_h

#define		NOTIFICATIONHISTORY_PATH					@"CallHistory"			//	Path name
#define		NOTIFICATIONHISTORY_OBJECTID				@"objectId"				//	String

#endif /* AppConstant_h */
