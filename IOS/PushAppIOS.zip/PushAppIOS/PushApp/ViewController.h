//
//  ViewController.h
//  PushApp
//
//  Created by tothesky on 20/03/2017.
//  Copyright © 2017 tothesky. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *txt_username;
@property (weak, nonatomic) IBOutlet UITextField *txt_password;

@end

