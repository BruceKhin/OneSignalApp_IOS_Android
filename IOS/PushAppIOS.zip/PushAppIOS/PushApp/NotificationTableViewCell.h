//
//  NotificationTableViewCell.h
//  PushApp
//
//  Created by tothesky on 21/03/2017.
//  Copyright © 2017 tothesky. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NotificationTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UITextView *txt_content;
@property (weak, nonatomic) IBOutlet UILabel *txt_title;
@property (weak, nonatomic) IBOutlet UIView *view_redbar;

@end
