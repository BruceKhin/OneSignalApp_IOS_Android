//
//  DetailNotificationViewController.m
//  PushApp
//
//  Created by tothesky on 25/03/2017.
//  Copyright © 2017 tothesky. All rights reserved.
//

#import "DetailNotificationViewController.h"
#import "DBNotificationHistory.h"
#import <Realm/Realm.h>

@interface DetailNotificationViewController ()
{
    RLMResults * tableDataArray;

}
@end

@implementation DetailNotificationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"Notifications";
    tableDataArray = [DBNotificationHistory allObjects];

    // Do any additional setup after loading the view.
    
    _lbl_title.text = _str_title;
    _txt_content.text = _str_content;
    
    _txt_content.editable = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btn_click:(UIBarButtonItem *)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btn_delete:(UIButton *)sender {
            
        NSUInteger index = [tableDataArray indexOfObjectWhere:@"objectId==%ld",[_str_objID integerValue]];
        if(index < [tableDataArray count])
        {
            [[RLMRealm defaultRealm] beginWriteTransaction];
            [[RLMRealm defaultRealm]deleteObject:[tableDataArray objectAtIndex:index]];
            [[RLMRealm defaultRealm] commitWriteTransaction];
        }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"RefreshMainTable" object:nil];

    
    [self.navigationController popViewControllerAnimated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
