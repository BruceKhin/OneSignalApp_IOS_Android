//
//  AppDelegate.m
//  PushApp
//
//  Created by tothesky on 20/03/2017.
//  Copyright © 2017 tothesky. All rights reserved.
//

#import "AppDelegate.h"
#import <IQKeyboardManager/IQKeyboardManager.h>
#import <OneSignal/OneSignal.h>
#import "GlobalVariable.h"
#import <Realm/Realm.h>
#import "DBNotificationHistory.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    [[IQKeyboardManager sharedManager] setEnable:YES];
    [self SETUPONESIGNAL:launchOptions];
    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}
-(void)SETUPONESIGNAL:(NSDictionary *)launchOptions
{
    
    [OneSignal initWithLaunchOptions:launchOptions appId:@"8a60ff58-6a39-4b4d-9f24-2ab271125d34" handleNotificationReceived:^(OSNotification *notification) {
       
        
    } handleNotificationAction:^(OSNotificationOpenedResult *result) {
        
        // This block gets called when the user reacts to a notification received
    } settings:@{kOSSettingsKeyInFocusDisplayOption : @(OSNotificationDisplayTypeNotification), kOSSettingsKeyAutoPrompt : @YES}];
    
    [OneSignal IdsAvailable:^(NSString *userId, NSString *pushToken) {
        [GlobalVariable instance].player_id = userId;
        NSLog(@"Userid = %@, PushToken = %@",userId,pushToken);
        
    }];    // Override point for customization after application launch.
    
    [OneSignal setLogLevel:ONE_S_LL_NONE visualLevel:ONE_S_LL_NONE];
    

}


- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler {
    
    //************************************************************
    // I only want this called if the user opened from swiping the push notification.
    // Otherwise I just want to update the local model
    //************************************************************
   
    

    NSDictionary *data = [[userInfo objectForKey:@"aps"] objectForKey:@"alert"];
    NSString* fullMessage = [data objectForKey:@"body"];
    NSString* messageTitle = [data objectForKey:@"title"];
    
    [self saveNotificationDataToRealm:messageTitle fullMessage:fullMessage];

    
    completionHandler(UIBackgroundFetchResultNewData);
}

-(void)saveNotificationDataToRealm:(NSString*)messageTitle fullMessage:(NSString*)fullMessage
{
    RLMRealm *realm = [RLMRealm defaultRealm];
    [realm beginWriteTransaction];
    DBNotificationHistory *information = [[DBNotificationHistory alloc] init];
    RLMResults *tableDataArray = [DBNotificationHistory allObjects];
    
    NSInteger data_id =  [[tableDataArray maxOfProperty:@"objectId"] integerValue];
    information.objectId =  data_id+1;
    information.title=messageTitle;
    information.content=fullMessage;
    
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyyMMdd"];
    NSString *yearString = [formatter stringFromDate:[NSDate date]];
    
    information.createdDate = yearString;
    [realm addObject:information];
    
    [realm commitWriteTransaction];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"RefreshMainTable" object:nil];

}
@end
