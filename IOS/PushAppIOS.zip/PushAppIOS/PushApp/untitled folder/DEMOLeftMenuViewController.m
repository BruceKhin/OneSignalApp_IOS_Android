//
//  DEMOLeftMenuViewController.m
//  RESideMenuStoryboards
//
//  Created by Roman Efimov on 10/9/13.
//  Copyright (c) 2013 Roman Efimov. All rights reserved.
//

#import "DEMOLeftMenuViewController.h"
#import "DEMOFirstViewController.h"
#import "DEMOSecondViewController.h"
#import "UIViewController+RESideMenu.h"
#import "ViewController.h"

#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

@interface DEMOLeftMenuViewController ()

@property (strong, readwrite, nonatomic) UITableView *tableView;
@property (strong, readwrite, nonatomic) UILabel *lbl_userName;
@property (strong, readwrite, nonatomic) UILabel *lbl_userEmail;
@property (strong, readwrite, nonatomic) UIImageView *img_logo;
@property (strong, readwrite, nonatomic) UISwitch *switch_notification;
@property (strong, readwrite, nonatomic) UIView *view_contactSecurity;

@end

@implementation DEMOLeftMenuViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.tableView = ({
        UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, (self.view.frame.size.height - 54 * 7) / 2.0f, self.view.frame.size.width, 54 * 7) style:UITableViewStylePlain];
        tableView.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleWidth;
        tableView.delegate = self;
        tableView.dataSource = self;
        tableView.opaque = NO;
        tableView.backgroundColor = [UIColor clearColor];
        tableView.backgroundView = nil;
        tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        tableView.bounces = NO;
        tableView.scrollsToTop = NO;
        tableView;
    });
    
    
    [self.view addSubview:self.tableView];

    UILabel *lbl_title = [[UILabel alloc] initWithFrame:CGRectMake(30, self.view.frame.size.height-45, 280, 50)];
    
    _switch_notification = [[UISwitch alloc] initWithFrame:CGRectMake(self.view.frame.size.width-80, self.view.frame.size.height-50, 50, 30)];
    _switch_notification.tintColor = UIColorFromRGB(0xEC384E);
    _switch_notification.onTintColor = UIColorFromRGB(0xEC384E);
    
    NSString *savedValue = [[NSUserDefaults standardUserDefaults]                           stringForKey:@"notify_status"];
    if([savedValue isEqualToString:@"NO"])
        [_switch_notification setOn:NO];
    else
        [_switch_notification setOn:YES];

    
    [_switch_notification addTarget:self action:@selector(changeSwitch:) forControlEvents:UIControlEventValueChanged];

    
    lbl_title.text = @"Snooze Notifications";
    lbl_title.font = [UIFont fontWithName:@"HelveticaNeue" size:17];

    [self.view addSubview:lbl_title];
    [lbl_title sizeToFit];
    
    _img_logo = [[UIImageView alloc] initWithFrame:CGRectMake(30, 46, 50, 50)];
    _img_logo.image = [UIImage imageNamed:@"logoicon"];
    
    _lbl_userName = [[UILabel alloc] initWithFrame:CGRectMake(90, 40, 200, 30)];
    _lbl_userName.text = @"Gegory Deas";
    
    _lbl_userEmail = [[UILabel alloc] initWithFrame:CGRectMake(90, 70, 200, 30)];
    _lbl_userEmail.text = @"gded@wiberforce.edu";
    
    
    _lbl_userName.font = [UIFont fontWithName:@"HelveticaNeue" size:22];
    _lbl_userEmail.font = [UIFont fontWithName:@"HelveticaNeue" size:13];

    _lbl_userEmail.textColor = [UIColor grayColor];
    _lbl_userName.textColor = [UIColor blackColor];
    
    [self.view addSubview:_switch_notification];
    [self.view addSubview:_img_logo];
    [self.view addSubview:_lbl_userEmail];
    [self.view addSubview:_lbl_userName];
}

-(void)changeSwitch:(id)sender{
    if([sender isOn]){
        if ([[UIApplication sharedApplication]respondsToSelector:@selector(isRegisteredForRemoteNotifications)])
        {
            [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeSound | UIUserNotificationTypeAlert | UIUserNotificationTypeBadge) categories:nil]];
            [[UIApplication sharedApplication] registerForRemoteNotifications];
        }
        else
        {
            [[UIApplication sharedApplication] registerForRemoteNotificationTypes:
             (UIUserNotificationTypeBadge | UIUserNotificationTypeSound | UIUserNotificationTypeAlert)];
        }
        [[NSUserDefaults standardUserDefaults] setObject:@"YES" forKey:@"notify_status"];
        

    } else{
        [[UIApplication sharedApplication] unregisterForRemoteNotifications];
        [[NSUserDefaults standardUserDefaults] setObject:@"NO" forKey:@"notify_status"];

    }
}

#pragma mark -
#pragma mark UITableView Delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:
            [self.sideMenuViewController setContentViewController:[[UINavigationController alloc] initWithRootViewController:[self.storyboard instantiateViewControllerWithIdentifier:@"secondViewController"]]
                                                         animated:YES];
            [self.sideMenuViewController hideMenuViewController];
            break;
        case 1:
            [self.sideMenuViewController setContentViewController:[[UINavigationController alloc] initWithRootViewController:[self.storyboard instantiateViewControllerWithIdentifier:@"SettingViewController"]]
                                                         animated:YES];
            [self.sideMenuViewController hideMenuViewController];
            break;
        case 5:
            [self gotoLoginScreen];
            break;
        default:
            break;
    }
}
-(void)gotoLoginScreen
{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
    [self presentViewController:vc animated:YES completion:nil];
}
#pragma mark -
#pragma mark UITableView Datasource

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 54;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return 7;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.textLabel.font = [UIFont fontWithName:@"HelveticaNeue" size:18];
        cell.textLabel.textColor = [UIColor blackColor];
        cell.textLabel.highlightedTextColor = [UIColor lightGrayColor];
        cell.selectedBackgroundView = [[UIView alloc] init];
    }
    if(indexPath.row < 6)
    {
        NSArray *titles = @[@"Notification", @"Settings", @"", @"",@"",@"Logout",@""];
        cell.textLabel.text = titles[indexPath.row];
        cell.imageView.image = [UIImage imageNamed:@"IconEmpty"];
        cell.imageView.hidden = YES;
        return cell;

    }
    else
    {
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width/4*3-40, 40)];
        
        float width = self.view.frame.size.width/4*3-40;
        UIImageView *img_security = [[UIImageView alloc] initWithFrame:CGRectMake((width-180)/2, 5, 30, 30)];
        img_security.image = [UIImage imageNamed:@"securityicon"];
        img_security.contentMode = UIViewContentModeScaleAspectFit;
        
        view.backgroundColor = UIColorFromRGB(0xEC384E);
        
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(40+(width-180)/2, 0, 140, 40)];
        label.text = @"Contact Security";
        label.font = [UIFont fontWithName:@"HelveticaNeue" size:18];
        label.textColor = [UIColor whiteColor];
        
        [view addSubview:label];
        [view addSubview:img_security];
        
        
        
        view.layer.cornerRadius = 8;
        [cell addSubview:view];
        view.center = cell.center;
        CGRect frame = view.frame;
        frame.origin.x = 20;
        frame.origin.y = 14;
        view.frame = frame;
       // cell.backgroundColor = UIColorFromRGB(0xEC384E);
        
        cell.imageView.hidden = YES;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;

    }
    return nil;
}

@end
