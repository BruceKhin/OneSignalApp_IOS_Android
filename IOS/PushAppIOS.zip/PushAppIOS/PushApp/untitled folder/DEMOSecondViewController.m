//
//  DEMOSecondViewController.m
//  RESideMenuStoryboards
//
//  Created by Roman Efimov on 10/9/13.
//  Copyright (c) 2013 Roman Efimov. All rights reserved.
//

#import "DEMOSecondViewController.h"
#import "NotificationTableViewCell.h"
#import "DetailNotificationViewController.h"
//#import "SVPullToRefresh.h"
#import <Realm/Realm.h>
#import "DBNotificationHistory.h"
#import "HeaderTableViewCell.h"
#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

@interface DEMOSecondViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    NSString* notification_title;
    NSString* notification_content;
    NSString* notification_id;

    
    RLMResults *tableDataArray;
    NSMutableArray *table_data_array_list;
    NSUInteger isClickecRightButton;
    NSArray *deleteItems;
    NSUInteger sectioncount;
}

@end

@implementation DEMOSecondViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    [self SETUPGUI];
    table_data_array_list = [NSMutableArray new];

    [self GetTableArrayData];
    
    isClickecRightButton = 0;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reInitListeners) name:@"RefreshMainTable" object:nil];

    // Do any additional setup after loading the view, typically from a nib.
}
-(void)reInitListeners
{
    [self GetTableArrayData];
    [_table_view reloadData];
    
}
-(void)GetTableArrayData
{
    
    tableDataArray = [DBNotificationHistory allObjects];
    
    NSMutableArray *array_new = [NSMutableArray new];
    for (NSUInteger i=0;i<[tableDataArray count];i++)
    {
        DBNotificationHistory *information = [tableDataArray objectAtIndex:i];;
        NSDictionary *dict = @{@"objectId": [NSNumber numberWithInteger:information.objectId],
                               @"content":information.content,
                               @"title":information.title,
                               @"createdDate":information.createdDate};
        [array_new addObject:dict];
    }
    
    NSArray *array = [array_new copy];
    NSSortDescriptor * descriptor = [[NSSortDescriptor alloc] initWithKey:@"objectId" ascending:NO];
    NSArray *filteredArray = [array sortedArrayUsingDescriptors:@[descriptor]];

    
    NSMutableArray *temp = [filteredArray mutableCopy];
    [self CreateFinalTableData:temp];
    
}

-(void)CreateFinalTableData:(NSMutableArray*)temp
{
    [table_data_array_list removeAllObjects];

    if([temp count]>0)
    {
        NSDictionary *the_first =[temp objectAtIndex:0];
        NSString *the_first_date = [the_first objectForKey:@"createdDate"];
        
        NSDictionary *the_first_dict = @{@"objectId": [NSNumber numberWithInteger:0],
                                         @"content":the_first_date,
                                         @"title":the_first_date,
                                         @"createdDate":the_first_date};
        
        [table_data_array_list addObject:the_first_dict];
        
        
        for(int i=0;i<[temp count]-1;i++)
        {
            NSDictionary *first =[temp objectAtIndex:i];
            NSDictionary *second =[temp objectAtIndex:i+1];
            
            NSString *first_date = [first objectForKey:@"createdDate"];
            NSString *second_date = [second objectForKey:@"createdDate"];
            
            if([first_date isEqual:second_date])
            {
                [table_data_array_list addObject:first];
            }
            else
            {
                [table_data_array_list addObject:first];
                
                NSDictionary *dict = @{@"objectId": [NSNumber numberWithInteger:0],
                                       @"content":second_date,
                                       @"title":second_date,
                                       @"createdDate":second_date};
                [table_data_array_list addObject:dict];
            }
        }
        
        NSDictionary *the_last =[temp objectAtIndex:[temp count]-1];
        [table_data_array_list addObject:the_last];
    }
}
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return UITableViewCellEditingStyleDelete;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dict = [table_data_array_list objectAtIndex:indexPath.row];
    NSUInteger str_id = [[dict objectForKey:@"objectId"] integerValue];
    NSString *str_title = [dict objectForKey:@"title"];
    NSString *str_content = [dict objectForKey:@"content"];
    
   if(str_id < 1)
   {
       
        HeaderTableViewCell *cell = (HeaderTableViewCell*)[tableView dequeueReusableCellWithIdentifier:@"HeaderTableViewCell" forIndexPath:indexPath];
       
       NSDateFormatter *dateformat = [[NSDateFormatter alloc] init];
       [dateformat setDateFormat:@"yyyyMMdd"];
       NSDate *myDate = [dateformat dateFromString:str_title];
       
       NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
       [formatter setFormatterBehavior:NSDateFormatterBehavior10_4];
       [formatter setDateStyle:NSDateFormatterLongStyle];
       [formatter setTimeStyle:NSDateFormatterNoStyle];
       NSString *result = [formatter stringFromDate:myDate];
       
       cell.txt_title.text = result;
       
       cell.selectionStyle = UITableViewCellSelectionStyleNone;
       return cell;
   }
   else
   {
       NotificationTableViewCell *cell = (NotificationTableViewCell*)[tableView dequeueReusableCellWithIdentifier:@"NotificationTableViewCell" forIndexPath:indexPath];
       
       cell.txt_title.text = str_title;
       cell.txt_content.text = str_content;
       cell.selectionStyle = UITableViewCellSelectionStyleDefault;

       return cell;
   }
    return nil;
}
-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSDictionary *dict = [table_data_array_list objectAtIndex:indexPath.row];
    NSUInteger str_id = [[dict objectForKey:@"objectId"] integerValue];
    if(str_id < 1)
        return NO;
    return YES;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [table_data_array_list count];
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dict = [table_data_array_list objectAtIndex:indexPath.row];
    NSInteger str_id = [[dict objectForKey:@"objectId"] integerValue];
    if(str_id < 1)
        return 40;
    else
        return 76;
    return 0;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dict = [table_data_array_list objectAtIndex:indexPath.row];
    if([[dict objectForKey:@"objectId"] integerValue] >0)
    {
        if(isClickecRightButton == 0)
        {
            NSDictionary *dict = [table_data_array_list objectAtIndex:indexPath.row];
            notification_title = [dict objectForKey:@"title"];
            notification_content = [dict objectForKey:@"content"];
            notification_id = [dict objectForKey:@"objectId"];
            [self performSegueWithIdentifier:@"segue_detail_notification" sender:self];
        }
        else
        {
            
        }
    }
}
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"segue_detail_notification"]) {
        DetailNotificationViewController *destWebViewController = segue.destinationViewController;
        // here we pass the URL
        destWebViewController.str_title = notification_title;
        destWebViewController.str_content = notification_content;
        destWebViewController.str_objID = notification_id;
    }
}

- (IBAction)right_navButton:(UIBarButtonItem *)sender {
    
    if(isClickecRightButton == 0)
    {
        isClickecRightButton = 1;
        _right_navButton.image = [UIImage imageNamed:@"checkicon"];
        _table_view.allowsMultipleSelectionDuringEditing = YES;
        [_table_view setEditing:YES];
        [_table_view reloadData];

    }
    else if(isClickecRightButton == 1)
    {
        isClickecRightButton = 0;
        
        deleteItems = [self.table_view indexPathsForSelectedRows];
        _right_navButton.image = [UIImage imageNamed:@"threedots"];
        
        
        NSArray *selectedCells = [self.table_view indexPathsForSelectedRows];
        deleteItems = selectedCells;
        if([selectedCells count]>0)
        {
            NSMutableIndexSet *indicesToDelete = [[NSMutableIndexSet alloc] init];
            for (NSIndexPath *indexPath in selectedCells) {
                [indicesToDelete addIndex:indexPath.row];
            }
            //arrayFromPlist is NSMutableArray

            _table_view.allowsMultipleSelectionDuringEditing = NO;
            [_table_view setEditing:NO];
            
            [self deleteRelamData];
            
            [self GetTableArrayData];

            [_table_view reloadData];
        }
        else
        {
            _table_view.allowsMultipleSelectionDuringEditing = NO;
            [_table_view setEditing:NO];
        }
    }

}
-(void)deleteRelamData
{
    for (NSIndexPath *indexPath in deleteItems) {
       NSInteger objectID =  [[[table_data_array_list objectAtIndex:indexPath.row] objectForKey:@"objectId"] integerValue];
        
        NSUInteger index = [tableDataArray indexOfObjectWhere:@"objectId==%ld",objectID];
        if(index < [tableDataArray count])
        {
            [[RLMRealm defaultRealm] beginWriteTransaction];
            [[RLMRealm defaultRealm]deleteObject:[tableDataArray objectAtIndex:index]];
            [[RLMRealm defaultRealm] commitWriteTransaction];
        }
     }
}
-(void)SETUPGUI
{
    //set up tableview
    
    _table_view.rowHeight = 76;
    _table_view.sectionHeaderHeight = 15;
    _table_view.scrollEnabled = YES;
    _table_view.showsVerticalScrollIndicator = YES;
    _table_view.userInteractionEnabled = YES;
    _table_view.backgroundColor = [UIColor clearColor];
    _table_view.separatorColor = [UIColor lightGrayColor];
    
    [_table_view setDataSource:self];
    [_table_view setDelegate:self];
    
}

@end
