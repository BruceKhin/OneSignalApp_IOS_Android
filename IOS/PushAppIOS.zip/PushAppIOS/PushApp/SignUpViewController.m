//
//  SignUpViewController.m
//  PushApp
//
//  Created by tothesky on 20/03/2017.
//  Copyright © 2017 tothesky. All rights reserved.
//

#import "SignUpViewController.h"
#import "AIDatePickerController.h"
@interface SignUpViewController ()

@end

@implementation SignUpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self SETUPGUI];
    // Do any additional setup after loading the view.
}


- (IBAction)btn_create:(UIButton *)sender {
    
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"rootController"];
    [self presentViewController:vc animated:YES completion:nil];
}
-(void)SETUPGUI
{
    [_txt_password setBackgroundColor:[UIColor clearColor]];
    [_txt_password setBorderStyle:UITextBorderStyleNone];
    
    [_txt_birthday setBackgroundColor:[UIColor clearColor]];
    [_txt_birthday setBorderStyle:UITextBorderStyleNone];
 
    [_txt_fullname setBackgroundColor:[UIColor clearColor]];
    [_txt_fullname setBorderStyle:UITextBorderStyleNone];
    
    [_txt_wwwemail setBackgroundColor:[UIColor clearColor]];
    [_txt_wwwemail setBorderStyle:UITextBorderStyleNone];

    _lbl_birthday.userInteractionEnabled = YES;
    UITapGestureRecognizer *tapGesture =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(labelTap)];
    [_lbl_birthday addGestureRecognizer:tapGesture];
    
    
  }

- (IBAction)btn_close:(UIButton *)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)labelTap
{
    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitDay | NSCalendarUnitMonth | NSCalendarUnitYear fromDate:[NSDate date]];
    NSInteger day = [components day];
    NSInteger month = [components month];
    NSInteger year = [components year];
    
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSDate *date = [dateFormatter dateFromString:[NSString stringWithFormat:@"%ld-%ld-%ld",day,month,year]];
    
    
    // Create an instance of the picker
    AIDatePickerController *datePickerViewController = [AIDatePickerController pickerWithDate:date selectedBlock:^(NSDate *selectedDate) {
        
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setFormatterBehavior:NSDateFormatterBehavior10_4];
        [formatter setDateStyle:NSDateFormatterLongStyle];
        [formatter setTimeStyle:NSDateFormatterNoStyle];
        NSString *result = [formatter stringFromDate:selectedDate];
        
        _lbl_birthday.text = result;

        [self dismissViewControllerAnimated:YES completion:nil];
        // Do what you want with the picked date.
    } cancelBlock:^{
        [self dismissViewControllerAnimated:YES completion:nil];

        // Do what you want when the user pressed the cancel button.
    }];
    
    // Present it
    [self presentViewController:datePickerViewController animated:YES completion:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btn_signin:(UIButton *)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
