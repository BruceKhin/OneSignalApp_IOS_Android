//
//  GlobalVariable.m
//  PushApp
//
//  Created by tothesky on 25/03/2017.
//  Copyright © 2017 tothesky. All rights reserved.
//

#import "GlobalVariable.h"

@implementation GlobalVariable

+ (instancetype)instance{
    static id instance = nil;
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        instance = [[self class] new];
    });
    
    return instance;
}
- (instancetype)init {
    self = [super init];
    if (self) {
        self.player_id = nil;
    }
    return self;
}

@end
