//
//  GlobalVariable.h
//  PushApp
//
//  Created by tothesky on 25/03/2017.
//  Copyright © 2017 tothesky. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Foundation/Foundation.h>

@interface GlobalVariable : NSObject
+ (instancetype)instance;

@property(strong, nonatomic, readwrite) NSString *player_id;

@end
