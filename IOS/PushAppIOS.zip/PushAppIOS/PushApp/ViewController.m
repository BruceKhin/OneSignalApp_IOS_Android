//
//  ViewController.m
//  PushApp
//
//  Created by tothesky on 20/03/2017.
//  Copyright © 2017 tothesky. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self SETUPGUI];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)btn_SignIn:(UIButton *)sender {
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"rootController"];
    [self presentViewController:vc animated:YES completion:nil];

    
}

- (IBAction)btn_signUP:(UIButton *)sender {
}
- (IBAction)btn_forget:(UIButton *)sender {
}

-(void)SETUPGUI
{
    [_txt_password setBackgroundColor:[UIColor clearColor]];
    [_txt_password setBorderStyle:UITextBorderStyleNone];
    
    [_txt_username setBackgroundColor:[UIColor clearColor]];
    [_txt_username setBorderStyle:UITextBorderStyleNone];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
