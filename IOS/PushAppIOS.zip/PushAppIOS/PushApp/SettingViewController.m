//
//  SettingViewController.m
//  PushApp
//
//  Created by tothesky on 20/03/2017.
//  Copyright © 2017 tothesky. All rights reserved.
//

#import "SettingViewController.h"

#import "AIDatePickerController.h"
#import "GlobalVariable.h"
#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]
@interface SettingViewController ()

@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self SETUPGUI];
    // Do any additional setup after loading the view.
}

- (IBAction)right_nav_button:(UIBarButtonItem *)sender {
}


-(void)SETUPGUI
{
    
    UIImage *nexicon = [UIImage imageWithIcon:@"fa-angle-right" backgroundColor:[UIColor clearColor] iconColor:[UIColor lightGrayColor] andSize:CGSizeMake(30, 30)];
    _img_nexicon.image = nexicon;
   
    
    _lbl_playerid.delegate = self;
    
    
    [_txt_password setBackgroundColor:[UIColor clearColor]];
    [_txt_password setBorderStyle:UITextBorderStyleNone];
    
    [_txt_fullname setBackgroundColor:[UIColor clearColor]];
    [_txt_fullname setBorderStyle:UITextBorderStyleNone];
    
    
    [_txt_email setBackgroundColor:[UIColor clearColor]];
    [_txt_email setBorderStyle:UITextBorderStyleNone];

    
    _lbl_playerid.text = [GlobalVariable instance].player_id;

    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)label:(TCCopyableLabel *)copyableLabel didCopyText:(NSString *)copiedText
{
    NSLog(@"%@",copiedText);
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
