//
//  SettingViewController.h
//  PushApp
//
//  Created by tothesky on 20/03/2017.
//  Copyright © 2017 tothesky. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RESideMenu.h"
#import "UIImage+FontAwesome.h"
#import "TCCopyableLabel.h"
@interface SettingViewController : UIViewController<TCCopyableLabelDelegate>
@property (weak, nonatomic) IBOutlet UIBarButtonItem *right_nav_button;


@property (weak, nonatomic) IBOutlet UITextField *txt_fullname;

@property (weak, nonatomic) IBOutlet UITextField *txt_email;
@property (weak, nonatomic) IBOutlet UITextField *txt_password;

@property (weak, nonatomic) IBOutlet UIImageView *img_nexicon;
@property (weak, nonatomic) IBOutlet TCCopyableLabel *lbl_playerid;
@property (weak, nonatomic) IBOutlet UILabel *lbl_tags;

@end
