//
//  NotificationHistory.h
//  PushApp
//
//  Created by tothesky on 25/03/2017.
//  Copyright © 2017 tothesky. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Realm/Realm.h>

@interface DBNotificationHistory : RLMObject
+ (long long)lastUpdatedAt;

@property NSInteger objectId;

@property NSString *content;
@property NSString *title;
@property NSString *createdDate;


@property long long createdAt;
@property long long updatedAt;


@end
