//
//  SignUpViewController.h
//  PushApp
//
//  Created by tothesky on 20/03/2017.
//  Copyright © 2017 tothesky. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignUpViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *txt_fullname;
@property (weak, nonatomic) IBOutlet UITextField *txt_wwwemail;

@property (weak, nonatomic) IBOutlet UITextField *txt_password;

@property (weak, nonatomic) IBOutlet UITextField *txt_birthday;


@property (weak, nonatomic) IBOutlet UILabel *lbl_birthday;
@end
